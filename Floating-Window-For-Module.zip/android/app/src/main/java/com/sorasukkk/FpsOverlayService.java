package com.sorasukkk;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;

public class FpsOverlayService extends Service implements FpsMonitor.Listener {
    private static final String CH = "sorasukkk_fps";
    private WindowManager wm;
    private View capsule;
    private WindowManager.LayoutParams cParams;
    private TextView fpsText;
    private TextView brandText;
    private FpsMonitor monitor;
    private FloatingWindowManager floatMgr;
    private float opacity = 0.85f;
    private float sizeScale = 1.0f;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatMgr = new FloatingWindowManager(this);
        monitor = new FpsMonitor();
        loadConfig();
        createCapsule();
        monitor.start(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("cfg")) {
            loadConfig();
            applyVisuals();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        monitor.stop();
        if (capsule != null) {
            try { wm.removeView(capsule); } catch (Throwable ignored) {}
        }
        floatMgr.close();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onFps(int fps) {
        main.post(() -> {
            if (fpsText == null) return;
            fpsText.setText(String.valueOf(fps));
            int color;
            if (fps > 55) color = 0xFF00F5D4;      // cyan
            else if (fps >= 30) color = 0xFFFF6B9D; // soft pink
            else color = 0xFFFF4D6D;                // hard pink/red
            fpsText.setTextColor(color);
        });
    }

    private void createCapsule() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(12), dp(7), dp(12), dp(7));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb((int)(opacity * 255), 18, 8, 26));
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1), 0x66FF6B9D);
        root.setBackground(bg);

        brandText = new TextView(this);
        brandText.setText("SORASUKKK");
        brandText.setTextSize(9 * sizeScale);
        brandText.setTextColor(0xFFFF6B9D);
        brandText.setGravity(Gravity.CENTER);
        root.addView(brandText);

        fpsText = new TextView(this);
        fpsText.setText("--");
        fpsText.setTextSize(18 * sizeScale);
        fpsText.setTextColor(0xFF00F5D4);
        fpsText.setGravity(Gravity.CENTER);
        root.addView(fpsText);

        cParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        cParams.gravity = Gravity.TOP | Gravity.END;
        cParams.x = dp(12);
        cParams.y = dp(80);

        root.setOnTouchListener(new View.OnTouchListener() {
            private int ix, iy, px, py;
            private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        ix = cParams.x; iy = cParams.y;
                        px = (int) e.getRawX(); py = (int) e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) e.getRawX() - px;
                        int dy = (int) e.getRawY() - py;
                        if (Math.abs(dx) > 4 || Math.abs(dy) > 4) moved = true;
                        cParams.x = ix - dx;
                        cParams.y = iy + dy;
                        wm.updateViewLayout(root, cParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) showAppPicker();
                        return true;
                }
                return false;
            }
        });

        capsule = root;
        wm.addView(root, cParams);
    }

    private void showAppPicker() {
        PopupMenu menu = new PopupMenu(this, capsule);
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        int id = 0;
        for (ApplicationInfo ai : apps) {
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            if (ai.packageName.equals(getPackageName())) continue;
            CharSequence label = ai.loadLabel(pm);
            menu.getMenu().add(0, id++, 0, label).setIntent(
                    new Intent().setPackage(ai.packageName));
        }
        menu.setOnMenuItemClickListener(item -> {
            String pkg = item.getIntent().getPackage();
            if (pkg != null) {
                floatMgr.showChrome(item.getTitle().toString());
                floatMgr.openApp(pkg);
            }
            return true;
        });
        menu.show();
    }

    private void loadConfig() {
        try (BufferedReader br = new BufferedReader(new FileReader("/data/adb/sorasukkk/config"))) {
            String line = br.readLine();
            if (line != null) {
                for (String part : line.split("\\s+")) {
                    if (part.startsWith("opacity=")) opacity = Float.parseFloat(part.substring(8));
                    if (part.startsWith("size=")) sizeScale = Float.parseFloat(part.substring(5));
                }
            }
        } catch (Throwable ignored) {}
    }

    private void applyVisuals() {
        if (capsule == null) return;
        GradientDrawable bg = (GradientDrawable) capsule.getBackground();
        if (bg != null) {
            bg.setColor(Color.argb((int)(opacity * 255), 18, 8, 26));
            bg.setStroke(dp(1), 0x66FF6B9D);
        }
        if (brandText != null) brandText.setTextSize(9 * sizeScale);
        if (fpsText != null) fpsText.setTextSize(18 * sizeScale);
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "SORASUKKK", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH)
                : new Notification.Builder(this);
        return b.setContentTitle("SORASUKKK")
                .setContentText("FPS capsule active · DARLING")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
