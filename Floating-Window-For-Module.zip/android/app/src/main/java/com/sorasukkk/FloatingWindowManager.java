package com.sorasukkk;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.app.ActivityOptions;
import android.util.DisplayMetrics;

/** Low-RAM floating window host. Freeform fallback (SurfaceControlViewHost needs privileged binder). */
public final class FloatingWindowManager {
    private final Context ctx;
    private final WindowManager wm;
    private View floatRoot;
    private WindowManager.LayoutParams params;

    public FloatingWindowManager(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
    }

    public void openApp(String packageName) {
        close();
        openFreeformFallback(packageName);
    }

    private void openFreeformFallback(String pkg) {
        try {
            Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) return;
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            if (Build.VERSION.SDK_INT >= 24) {
                ActivityOptions opts = ActivityOptions.makeBasic();
                opts.setLaunchWindowingMode(5); // WINDOWING_MODE_FREEFORM
                ctx.startActivity(launch, opts.toBundle());
            } else {
                ctx.startActivity(launch);
            }
        } catch (Throwable ignored) {}
    }

    public void showChrome(String title) {
        close();
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        int w = (int) (dm.widthPixels * 0.7f);
        int h = (int) (dm.heightPixels * 0.5f);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xE012081A);

        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(16, 12, 16, 12);
        bar.setBackgroundColor(0xFF0A0610);

        TextView label = new TextView(ctx);
        label.setText("SORASUKKK · " + title);
        label.setTextColor(0xFFFF6B9D);
        label.setTextSize(13);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(label);

        TextView close = new TextView(ctx);
        close.setText("✕");
        close.setTextColor(0xFFFF4D6D);
        close.setTextSize(16);
        close.setPadding(12, 0, 0, 0);
        close.setOnClickListener(v -> close());
        bar.addView(close);
        root.addView(bar);

        FrameLayout content = new FrameLayout(ctx);
        content.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        content.setBackgroundColor(0xFF0A0610);
        root.addView(content);

        View handle = new View(ctx);
        handle.setBackgroundColor(0xFF00F5D4);
        handle.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 8));
        root.addView(handle);

        params = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 120;

        bar.setOnTouchListener(new View.OnTouchListener() {
            private int ix, iy, px, py;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        ix = params.x; iy = params.y;
                        px = (int) e.getRawX(); py = (int) e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = ix + (int) e.getRawX() - px;
                        params.y = iy + (int) e.getRawY() - py;
                        wm.updateViewLayout(root, params);
                        return true;
                }
                return false;
            }
        });

        handle.setOnTouchListener(new View.OnTouchListener() {
            private int iw, ih, px, py;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        iw = params.width; ih = params.height;
                        px = (int) e.getRawX(); py = (int) e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.width = Math.max(200, iw + (int) e.getRawX() - px);
                        params.height = Math.max(150, ih + (int) e.getRawY() - py);
                        wm.updateViewLayout(root, params);
                        return true;
                }
                return false;
            }
        });

        floatRoot = root;
        wm.addView(root, params);
    }

    public void close() {
        if (floatRoot != null) {
            try { wm.removeView(floatRoot); } catch (Throwable ignored) {}
            floatRoot = null;
        }
    }
}
