package com.sorasukkk;

import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** Lightweight FPS sampler — dumpsys SurfaceFlinger preferred, Choreographer fallback. */
public final class FpsMonitor {
    public interface Listener { void onFps(int fps); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicInteger lastFps = new AtomicInteger(0);
    private Listener listener;
    private boolean running;
    private Choreographer.FrameCallback frameCb;
    private final long[] frameTimes = new long[64];
    private int frameIdx;
    private Thread dumpThread;

    public void start(Listener l) {
        listener = l;
        running = true;
        startDumpsysLoop();
        startChoreographerFallback();
    }

    public void stop() {
        running = false;
        if (frameCb != null) Choreographer.getInstance().removeFrameCallback(frameCb);
        if (dumpThread != null) dumpThread.interrupt();
    }

    public int getLastFps() { return lastFps.get(); }

    private void startDumpsysLoop() {
        dumpThread = new Thread(() -> {
            while (running) {
                try {
                    int fps = sampleSurfaceFlinger();
                    if (fps > 0) {
                        lastFps.set(fps);
                        main.post(() -> { if (listener != null) listener.onFps(fps); });
                    }
                    Thread.sleep(900);
                } catch (InterruptedException e) {
                    break;
                } catch (Throwable ignored) {}
            }
        }, "sorasukkk-fps");
        dumpThread.setPriority(Thread.MIN_PRIORITY);
        dumpThread.start();
    }

    private int sampleSurfaceFlinger() {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "dumpsys SurfaceFlinger"});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line, layer = null;
            while ((line = br.readLine()) != null) {
                if (line.contains("Focused") || line.contains("mCurrentFocus")) {
                    int i = line.indexOf("Surface");
                    if (i > 0) layer = line.substring(i).trim().split("\\s+")[0];
                }
            }
            br.close();
            p.waitFor();
            if (layer == null || layer.isEmpty()) return -1;

            Process lat = Runtime.getRuntime().exec(new String[]{
                    "su", "-c", "dumpsys SurfaceFlinger --latency " + layer});
            BufferedReader lr = new BufferedReader(new InputStreamReader(lat.getInputStream()));
            List<Long> ts = new ArrayList<>(32);
            while ((line = lr.readLine()) != null) {
                String[] parts = line.trim().split("\\s+");
                if (parts.length >= 3) {
                    try {
                        long t = Long.parseLong(parts[1]);
                        if (t > 0) ts.add(t);
                    } catch (NumberFormatException ignored) {}
                }
            }
            lr.close();
            lat.waitFor();
            if (ts.size() < 2) return -1;
            long deltaNs = ts.get(ts.size() - 1) - ts.get(0);
            if (deltaNs <= 0) return -1;
            double sec = deltaNs / 1_000_000_000.0;
            return (int) Math.round((ts.size() - 1) / sec);
        } catch (Throwable t) {
            return -1;
        }
    }

    private void startChoreographerFallback() {
        frameCb = new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!running) return;
                frameTimes[frameIdx++ % frameTimes.length] = frameTimeNanos;
                if (frameIdx >= 16) {
                    long oldest = frameTimes[frameIdx % frameTimes.length];
                    long newest = frameTimeNanos;
                    long delta = newest - oldest;
                    if (delta > 0) {
                        int fps = (int) Math.round(1_000_000_000.0 * (frameTimes.length - 1) / delta);
                        if (lastFps.get() <= 0) {
                            lastFps.set(fps);
                            if (listener != null) listener.onFps(fps);
                        }
                    }
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        };
        Choreographer.getInstance().postFrameCallback(frameCb);
    }
}
